<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('customer_id')->constrained('users');
            $table->foreignId('sales_rep_id')->constrained('users');
            $table->foreignId('supervisor_id')->nullable()->constrained('users');
            $table->enum('status', [
                'pending',
                'confirmed',
                'processing',
                'completed',
                'cancelled',
                'archived'
            ])->default('pending');
            $table->decimal('total_amount', 10, 2);
            $table->boolean('is_approved_by_customer')->default(false);
            $table->timestamp('approved_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamp('archived_at')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::dropIfExists('orders');
    }
};