@extends('layouts.app')

@section('content')
<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h2 class="mb-0">Order #{{ $order->id }}</h2>
                <div>
                    @if(auth()->user()->role === 'super_admin' || 
                        (auth()->user()->role === 'sales_supervisor' && $order->status === 'pending'))
                        <div class="dropdown d-inline-block me-2">
                            <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                Update Status
                            </button>
                            <ul class="dropdown-menu">
                                <li>
                                    <form method="POST" action="{{ route('orders.updateStatus', $order) }}">
                                        @csrf
                                        @method('PUT')
                                        <input type="hidden" name="status" value="confirmed">
                                        <button type="submit" class="dropdown-item">Confirm</button>
                                    </form>
                                </li>
                                <li>
                                    <form method="POST" action="{{ route('orders.updateStatus', $order) }}">
                                        @csrf
                                        @method('PUT')
                                        <input type="hidden" name="status" value="processing">
                                        <button type="submit" class="dropdown-item">Processing</button>
                                    </form>
                                </li>
                                <li>
                                    <form method="POST" action="{{ route('orders.updateStatus', $order) }}">
                                        @csrf
                                        @method('PUT')
                                        <input type="hidden" name="status" value="completed">
                                        <button type="submit" class="dropdown-item">Complete</button>
                                    </form>
                                </li>
                                <li>
                                    <form method="POST" action="{{ route('orders.updateStatus', $order) }}">
                                        @csrf
                                        @method('PUT')
                                        <input type="hidden" name="status" value="cancelled">
                                        <button type="submit" class="dropdown-item">Cancel</button>
                                    </form>
                                </li>
                                <li>
                                    <form method="POST" action="{{ route('orders.updateStatus', $order) }}">
                                        @csrf
                                        @method('PUT')
                                        <input type="hidden" name="status" value="archived">
                                        <button type="submit" class="dropdown-item">Archive</button>
                                    </form>
                                </li>
                            </ul>
                        </div>
                    @endif
                    <a href="{{ route('orders.index') }}" class="btn btn-secondary">
                        <i class="bi bi-arrow-left"></i> Back
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h5>Order Information</h5>
                        <p><strong>Status:</strong> 
                            <span class="badge bg-{{ 
                                $order->status === 'completed' ? 'success' :
                                ($order->status === 'cancelled' ? 'danger' :
                                ($order->status === 'processing' ? 'info' :
                                ($order->status === 'confirmed' ? 'primary' :
                                ($order->status === 'archived' ? 'secondary' : 'warning'))))
                            }}">
                                {{ ucfirst($order->status) }}
                            </span>
                        </p>
                        <p><strong>Created:</strong> {{ $order->created_at->format('F j, Y g:i A') }}</p>
                        @if($order->approved_at)
                            <p><strong>Approved:</strong> {{ $order->approved_at->format('F j, Y g:i A') }}</p>
                        @endif
                        @if($order->completed_at)
                            <p><strong>Completed:</strong> {{ $order->completed_at->format('F j, Y g:i A') }}</p>
                        @endif
                    </div>
                    <div class="col-md-6">
                        <h5>Customer Information</h5>
                        <p><strong>Name:</strong> {{ $order->customer->name }}</p>
                        <p><strong>Email:</strong> {{ $order->customer->email }}</p>
                        <p><strong>Sales Rep:</strong> {{ $order->salesRep->name }}</p>
                        @if($order->supervisor)
                            <p><strong>Supervisor:</strong> {{ $order->supervisor->name }}</p>
                        @endif
                    </div>
                </div>

                <h5>Order Items</h5>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Quantity</th>
                                <th>Unit Price</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($order->items as $item)
                                <tr>
                                    <td>{{ $item->product->name }}</td>
                                    <td>{{ $item->quantity }}</td>
                                    <td>${{ number_format($item->unit_price, 2) }}</td>
                                    <td>${{ number_format($item->total_price, 2) }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="3" class="text-end"><strong>Total Amount:</strong></td>
                                <td><strong>${{ number_format($order->total_amount, 2) }}</strong></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                @if($order->notes)
                    <div class="mt-4">
                        <h5>Notes</h5>
                        <p class="mb-0">{{ $order->notes }}</p>
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection