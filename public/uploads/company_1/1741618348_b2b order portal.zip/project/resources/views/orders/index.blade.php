@extends('layouts.app')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Orders</h1>
    @if(in_array(auth()->user()->role, ['sales_supervisor', 'sales_representative']))
        <a href="{{ route('orders.create') }}" class="btn btn-primary">
            <i class="bi bi-plus-lg"></i> Create Order
        </a>
    @endif
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Customer</th>
                        <th>Sales Rep</th>
                        <th>Status</th>
                        <th>Total Amount</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($orders as $order)
                        <tr>
                            <td>{{ $order->id }}</td>
                            <td>{{ $order->customer->name }}</td>
                            <td>{{ $order->salesRep->name }}</td>
                            <td>
                                <span class="badge bg-{{ 
                                    $order->status === 'completed' ? 'success' :
                                    ($order->status === 'cancelled' ? 'danger' :
                                    ($order->status === 'processing' ? 'info' :
                                    ($order->status === 'confirmed' ? 'primary' :
                                    ($order->status === 'archived' ? 'secondary' : 'warning'))))
                                }}">
                                    {{ ucfirst($order->status) }}
                                </span>
                            </td>
                            <td>${{ number_format($order->total_amount, 2) }}</td>
                            <td>{{ $order->created_at->format('M d, Y') }}</td>
                            <td>
                                <div class="btn-group">
                                    <a href="{{ route('orders.show', $order) }}" class="btn btn-sm btn-info">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    @if($order->status === 'pending' && auth()->user()->role === 'customer' && $order->customer_id === auth()->id())
                                        <form method="POST" action="{{ route('orders.approve', $order) }}">
                                            @csrf
                                            <button type="submit" class="btn btn-sm btn-success">
                                                <i class="bi bi-check-lg"></i>
                                            </button>
                                        </form>
                                    @endif
                                </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="mt-4">
    {{ $orders->links() }}
</div>
@endsection