@extends('layouts.app')

@section('content')
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h2 class="mb-0">User Details</h2>
                <div>
                    @if(auth()->user()->role === 'super_admin')
                        <a href="{{ route('users.edit', $user) }}" class="btn btn-warning">
                            <i class="bi bi-pencil"></i> Edit
                        </a>
                    @endif
                    <a href="{{ route('users.index') }}" class="btn btn-secondary">
                        <i class="bi bi-arrow-left"></i> Back
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h5>Basic Information</h5>
                        <p><strong>Name:</strong> {{ $user->name }}</p>
                        <p><strong>Email:</strong> {{ $user->email }}</p>
                        <p><strong>Role:</strong> 
                            <span class="badge bg-{{ 
                                $user->role === 'super_admin' ? 'danger' :
                                ($user->role === 'sales_supervisor' ? 'primary' :
                                ($user->role === 'sales_representative' ? 'info' : 'success'))
                            }}">
                                {{ str_replace('_', ' ', ucfirst($user->role)) }}
                            </span>
                        </p>
                        <p><strong>Status:</strong> 
                            <span class="badge bg-{{ $user->is_active ? 'success' : 'danger' }}">
                                {{ $user->is_active ? 'Active' : 'Inactive' }}
                            </span>
                        </p>
                    </div>
                    <div class="col-md-6">
                        <h5>Additional Information</h5>
                        <p><strong>Created:</strong> {{ $user->created_at->format('F j, Y g:i A') }}</p>
                        <p><strong>Last Updated:</strong> {{ $user->updated_at->format('F j, Y g:i A') }}</p>
                        @if($user->supervisor)
                            <p><strong>Supervisor:</strong> {{ $user->supervisor->name }}</p>
                        @endif
                    </div>
                </div>

                @if($user->role === 'sales_supervisor')
                    <div class="mb-4">
                        <h5>Sales Team</h5>
                        @if($user->salesTeam->count() > 0)
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($user->salesTeam as $member)
                                            <tr>
                                                <td>{{ $member->name }}</td>
                                                <td>{{ $member->email }}</td>
                                                <td>
                                                    <span class="badge bg-{{ $member->is_active ? 'success' : 'danger' }}">
                                                        {{ $member->is_active ? 'Active' : 'Inactive' }}
                                                    </span>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @else
                            <p class="text-muted">No team members assigned yet.</p>
                        @endif
                    </div>
                @endif

                @if($user->orders->count() > 0)
                    <div>
                        <h5>Recent Orders</h5>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Status</th>
                                        <th>Total Amount</th>
                                        <th>Created</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($user->orders->take(5) as $order)
                                        <tr>
                                            <td>{{ $order->id }}</td>
                                            <td>
                                                <span class="badge bg-{{ 
                                                    $order->status === 'completed' ? 'success' :
                                                    ($order->status === 'cancelled' ? 'danger' :
                                                    ($order->status === 'processing' ? 'info' :
                                                    ($order->status === 'confirmed' ? 'primary' :
                                                    ($order->status === 'archived' ? 'secondary' : 'warning'))))
                                                }}">
                                                    {{ ucfirst($order->status) }}
                                                </span>
                                            </td>
                                            <td>${{ number_format($order->total_amount, 2) }}</td>
                                            <td>{{ $order->created_at->format('M d, Y') }}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection