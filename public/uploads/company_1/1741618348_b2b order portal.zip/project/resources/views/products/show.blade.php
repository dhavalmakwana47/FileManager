@extends('layouts.app')

@section('content')
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h2 class="mb-0">Product Details</h2>
                <div>
                    @if(auth()->user()->role === 'super_admin')
                        <a href="{{ route('products.edit', $product) }}" class="btn btn-warning">
                            <i class="bi bi-pencil"></i> Edit
                        </a>
                    @endif
                    <a href="{{ route('products.index') }}" class="btn btn-secondary">
                        <i class="bi bi-arrow-left"></i> Back
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        @if($product->image_url)
                            <img src="{{ $product->image_url }}" alt="{{ $product->name }}" class="img-fluid rounded">
                        @else
                            <div class="bg-light rounded d-flex align-items-center justify-content-center" style="height: 200px">
                                <span class="text-muted">No image available</span>
                            </div>
                        @endif
                    </div>
                    <div class="col-md-8">
                        <h3>{{ $product->name }}</h3>
                        <p class="text-muted">{{ $product->description }}</p>
                        
                        <div class="row mt-4">
                            <div class="col-6">
                                <h5>Price</h5>
                                <p class="h3 text-primary">${{ number_format($product->price, 2) }}</p>
                            </div>
                            <div class="col-6">
                                <h5>Minimum Quantity</h5>
                                <p class="h3">{{ $product->min_quantity }}</p>
                            </div>
                        </div>

                        <div class="mt-4">
                            <h5>Status</h5>
                            <span class="badge bg-{{ $product->is_active ? 'success' : 'danger' }} fs-6">
                                {{ $product->is_active ? 'Active' : 'Inactive' }}
                            </span>
                        </div>

                        <div class="mt-4">
                            <h5>Created</h5>
                            <p>{{ $product->created_at->format('F j, Y g:i A') }}</p>
                            
                            <h5>Last Updated</h5>
                            <p>{{ $product->updated_at->format('F j, Y g:i A') }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection