<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function index()
    {
        $users = User::with('supervisor')->paginate(10);
        return view('users.index', compact('users'));
    }

    public function create()
    {
        $supervisors = User::where('role', 'sales_supervisor')->get();
        return view('users.create', compact('supervisors'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
            'role' => 'required|in:super_admin,sales_supervisor,sales_representative,customer',
            'supervisor_id' => 'nullable|exists:users,id',
            'is_active' => 'boolean'
        ]);

        $validated['password'] = Hash::make($validated['password']);

        User::create($validated);

        return redirect()->route('users.index')
            ->with('success', 'User created successfully.');
    }

    public function show(User $user)
    {
        $user->load(['supervisor', 'salesTeam', 'orders']);
        return view('users.show', compact('user'));
    }

    public function edit(User $user)
    {
        $supervisors = User::where('role', 'sales_supervisor')
            ->where('id', '!=', $user->id)
            ->get();
        return view('users.edit', compact('user', 'supervisors'));
    }

    public function update(Request $request, User $user)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email,' . $user->id,
            'password' => 'nullable|string|min:8|confirmed',
            'role' => 'required|in:super_admin,sales_supervisor,sales_representative,customer',
            'supervisor_id' => 'nullable|exists:users,id',
            'is_active' => 'boolean'
        ]);

        if (isset($validated['password'])) {
            $validated['password'] = Hash::make($validated['password']);
        } else {
            unset($validated['password']);
        }

        $user->update($validated);

        return redirect()->route('users.index')
            ->with('success', 'User updated successfully.');
    }

    public function destroy(User $user)
    {
        $user->delete();

        return redirect()->route('users.index')
            ->with('success', 'User deleted successfully.');
    }
}