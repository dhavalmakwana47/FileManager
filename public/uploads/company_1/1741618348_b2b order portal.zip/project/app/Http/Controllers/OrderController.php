<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    public function index()
    {
        $orders = Order::with(['customer', 'salesRep', 'supervisor'])
            ->paginate(10);
        return view('orders.index', compact('orders'));
    }

    public function create()
    {
        $products = Product::where('is_active', true)->get();
        return view('orders.create', compact('products'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'customer_id' => 'required|exists:users,id',
            'products' => 'required|array',
            'products.*.id' => 'required|exists:products,id',
            'products.*.quantity' => 'required|integer|min:1',
            'notes' => 'nullable|string'
        ]);

        DB::transaction(function () use ($validated) {
            $order = Order::create([
                'customer_id' => $validated['customer_id'],
                'sales_rep_id' => auth()->id(),
                'status' => 'pending',
                'total_amount' => 0,
                'notes' => $validated['notes'] ?? null
            ]);

            $totalAmount = 0;
            foreach ($validated['products'] as $item) {
                $product = Product::findOrFail($item['id']);
                $totalPrice = $product->price * $item['quantity'];
                $totalAmount += $totalPrice;

                $order->items()->create([
                    'product_id' => $product->id,
                    'quantity' => $item['quantity'],
                    'unit_price' => $product->price,
                    'total_price' => $totalPrice
                ]);
            }

            $order->update(['total_amount' => $totalAmount]);
        });

        return redirect()->route('orders.index')
            ->with('success', 'Order created successfully.');
    }

    public function show(Order $order)
    {
        $order->load(['customer', 'salesRep', 'supervisor', 'items.product']);
        return view('orders.show', compact('order'));
    }

    public function updateStatus(Request $request, Order $order)
    {
        $validated = $request->validate([
            'status' => 'required|in:pending,confirmed,processing,completed,cancelled,archived'
        ]);

        $order->update([
            'status' => $validated['status'],
            'completed_at' => in_array($validated['status'], ['completed', 'archived']) ? now() : null,
            'archived_at' => $validated['status'] === 'archived' ? now() : null
        ]);

        return redirect()->route('orders.show', $order)
            ->with('success', 'Order status updated successfully.');
    }

    public function approve(Order $order)
    {
        $order->update([
            'is_approved_by_customer' => true,
            'approved_at' => now(),
            'status' => 'confirmed'
        ]);

        return redirect()->route('orders.show', $order)
            ->with('success', 'Order approved successfully.');
    }
}