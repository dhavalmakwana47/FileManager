<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Order extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'customer_id',
        'sales_rep_id',
        'supervisor_id',
        'status',
        'total_amount',
        'is_approved_by_customer',
        'approved_at',
        'completed_at',
        'archived_at',
        'notes'
    ];

    protected $casts = [
        'total_amount' => 'decimal:2',
        'is_approved_by_customer' => 'boolean',
        'approved_at' => 'datetime',
        'completed_at' => 'datetime',
        'archived_at' => 'datetime',
    ];

    public function customer()
    {
        return $this->belongsTo(User::class, 'customer_id');
    }

    public function salesRep()
    {
        return $this->belongsTo(User::class, 'sales_rep_id');
    }

    public function supervisor()
    {
        return $this->belongsTo(User::class, 'supervisor_id');
    }

    public function items()
    {
        return $this->hasMany(OrderItem::class);
    }
}